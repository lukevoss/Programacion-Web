<?php
$asig = $_POST['asig'];
echo $asig;